package backand;

public class my_servalate {
    public static void main(String args[]) {
    	
    }
}
